<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	require_once("database/connection.php");
	require_once("safe_json_encode.php");
	$email = $_GET['email'];
	$senha = $_GET['senha'];


    $sql = "SELECT * FROM cadastro WHERE email = '$email' AND senha = '$senha'";
    $result = mysqli_query($conn, $sql);
	$isValido = false;
	
    while ( $dados = mysqli_fetch_assoc($result) ) 
    {  
		$response[] = array(
			"id" => $dados['id'],
			"nome"=> $dados['nome'],
			"email" => $dados['email'],
			"cpf" => $dados['cpf'],
			"endereco" => $dados['endereco'],
			"telefone" => $dados['telefone']
	
		);
		$isValido = true;
		http_response_code(200);
	}

	if($isValido){
		$json = $response;
		echo safe_json_encode($response);
	} else {
		$json = array(
			"erro" => 'usuario nao encontrado',
		);
		http_response_code(422);
		echo safe_json_encode($json);
	}
	
?>