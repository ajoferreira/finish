<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	require_once("database/connection.php");
	require_once("safe_json_encode.php");

    $sql = "SELECT * FROM cadprof";
    $result = mysqli_query($conn, $sql);
	
    while ( $dados = mysqli_fetch_assoc($result) ) 
    {  
		$response[] = array(
			"id" => $dados['id'],
			"foto"=> $dados['foto'],
			"nomeprof"=> $dados['nomeprof'],
			"especialidade"=> $dados['especialidade'],
			"crp" => $dados['crp'],
			"sobre" => $dados['sobre'],
			"formacao" => $dados['formacao'],
			"lugar" => $dados['lugar'],
			"telefoneprof" => $dados['telefoneprof'],
			"emailprof" => $dados['emailprof'],
			"idiomas" => $dados['idiomas']
		);
		http_response_code(200);
	}

	$json = $response;

	echo safe_json_encode($response);
	
?>