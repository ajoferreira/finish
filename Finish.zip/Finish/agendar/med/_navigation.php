            <div class="space">
                <a href="doctor.php">Doutor</a>
                |
                <a href="manager.php">Gerente</a>
                |
                <a href="../index.php" class="btn btn-primary" value="Home">Sair</a>
            </div>
