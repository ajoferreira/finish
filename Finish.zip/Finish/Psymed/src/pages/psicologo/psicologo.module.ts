import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PsicologoPage } from './psicologo';

@NgModule({
  declarations: [
    PsicologoPage,
  ],
  imports: [
    IonicPageModule.forChild(PsicologoPage),
  ],
})
export class PsicologoPageModule {}
